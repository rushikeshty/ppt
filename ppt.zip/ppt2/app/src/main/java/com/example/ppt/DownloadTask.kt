//package com.example.ppt
//
//import android.content.Context
//import android.content.Intent
//import android.os.AsyncTask
//import android.net.Uri
// import android.os.Environment
//import android.util.Log
//import android.widget.Toast
//import java.io.*
//import java.net.HttpURLConnection
//import java.net.URL
//class DownloadTask(private val context: Context, private val url: String) :
//    AsyncTask<Void, Void, Boolean>() {
//
//    override fun doInBackground(vararg params: Void?): Boolean {
//
//    }
//
//    @Deprecated("Deprecated in Java")
//    override fun onPostExecute(result: Boolean) {
//
//    }
//
//
//}
//
