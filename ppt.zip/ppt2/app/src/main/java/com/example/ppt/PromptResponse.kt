package com.example.ppt

data class PromptResponse(
    val prompt: Prompt
)

data class Prompt(
    val text: String
)

